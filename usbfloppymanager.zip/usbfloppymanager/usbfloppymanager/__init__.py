"""USBFloppyManager - gestor de USB para Gotek con firmware original (slots en crudo)."""
__version__ = "0.1.0"
