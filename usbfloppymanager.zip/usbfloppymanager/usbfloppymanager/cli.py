from __future__ import annotations
import argparse, os, sys

from . import __version__
from .batch import MODES, run_batch, write_contents
from .core import (Device, GotekError, Slot, SLOT_SIZE, backup_device, export_image,
                   import_image)
from .devices import list_usb_devices


def human(n: int) -> str:
    for u in ("B", "KiB", "MiB", "GiB"):
        if n < 1024 or u == "GiB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024


def confirm(msg: str, assume_yes: bool):
    if assume_yes:
        return
    if input(f"{msg}\nEscribe 'si' para continuar: ").strip().lower() not in ("si", "sí", "yes", "y"):
        raise GotekError("Cancelado por el usuario.")


def cmd_devices(a):
    devs = list_usb_devices()
    if not devs:
        print("No se detectaron dispositivos USB extraíbles.")
    for d in devs:
        print(f"{d.path}\t{human(d.size)}\t{d.model}")


def cmd_list(a):
    with Device(a.device, slots=a.slots) as d:
        print(f"{d.path}: {d.n_slots} slots")
        for i in d.iter_info():
            if i.valid:
                print(f"{i.index:3d}  {i.label:<11} {i.files:3d} archivos  {human(i.used_bytes):>9} usados")
            elif a.all:
                print(f"{i.index:3d}  (sin FAT12 válido)")


def cmd_ls(a):
    with Device(a.device, slots=a.slots) as d, Slot(d, a.slot) as s:
        for e in s.walk():
            print(f"{'<DIR>' if e.is_dir else human(e.size):>10}  {e.path}")


def cmd_format(a):
    with Device(a.device, writable=True, slots=a.slots) as d:
        for n in a.slot:
            confirm(f"Se BORRARÁ el slot {n} de {a.device}.", a.yes)
            d.format_slot(n, a.label or f"FD{n:03d}")
            print(f"Slot {n} formateado.")


def cmd_put(a):
    with Device(a.device, writable=True, slots=a.slots) as d, Slot(d, a.slot) as s:
        for f in a.files:
            dest = (a.dest.strip("/") + "/" if a.dest else "") + os.path.basename(f)
            s.write("/" + dest, open(f, "rb").read())
            print(f"{f} -> slot {a.slot}:/{dest}")


def cmd_get(a):
    with Device(a.device, slots=a.slots) as d, Slot(d, a.slot) as s:
        data = s.read("/" + a.path.strip("/"))
        out = a.out or os.path.basename(a.path)
        open(out, "wb").write(data)
        print(f"Guardado {out} ({human(len(data))})")


def cmd_rm(a):
    with Device(a.device, writable=True, slots=a.slots) as d, Slot(d, a.slot) as s:
        s.remove("/" + a.path.strip("/"))
        print("Eliminado.")


def cmd_export(a):
    with Device(a.device, slots=a.slots) as d:
        export_image(d, a.slot, a.out)
        print(f"Slot {a.slot} -> {a.out}")


def cmd_import(a):
    with Device(a.device, writable=True, slots=a.slots) as d:
        confirm(f"Se SOBRESCRIBIRÁ el slot {a.slot} de {a.device}.", a.yes)
        import_image(d, a.slot, a.image)
        print(f"{a.image} -> slot {a.slot}")


def cmd_backup(a):
    with Device(a.device, slots=a.slots) as d:
        backup_device(d, a.out, lambda i, n: print(f"\r{i}/{n}", end="", flush=True))
        print(f"\nCopia guardada en {a.out}")


def cmd_batch(a):
    mode = a.mode
    if a.dry_run:
        res = run_batch(a.src, a.start, mode)
        print("(Estimación; la copia real es la que manda.)")
    else:
        with Device(a.device, writable=True, slots=a.slots) as d:
            confirm(f"Se BORRARÁN los slots {a.start}.. de {a.device} y se copiará {a.src}.", a.yes)
            res = run_batch(a.src, a.start, mode, d,
                            lambda p: print(f"{p.floppy:03d}: {p.dest}" + ("  [DEMASIADO GRANDE]" if p.status == 'too_big' else "")))
    print(f"\nDisquetes usados: {res.first}..{res.last}  ({len(res.placements)} archivos, {len(res.skipped)} omitidos)")
    if a.dry_run:
        for p in res.placements:
            print(f"{p.floppy:03d}  {p.dest}")
    else:
        print("Índice:", write_contents(res, a.contents_dir))


def build_parser():
    p = argparse.ArgumentParser(prog="usbfloppy", description="Gestor de USB para Gotek (firmware original).")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="cmd", required=True)

    def add(name, fn, help, dev=True, write=False):
        sp = sub.add_parser(name, help=help)
        if dev:
            sp.add_argument("device", help="/dev/sdX, \\\\.\\PhysicalDriveN o archivo .img")
            sp.add_argument("--slots", type=int, help="nº de slots si no se detecta el tamaño")
        if write:
            sp.add_argument("-y", "--yes", action="store_true", help="no pedir confirmación")
        sp.set_defaults(fn=fn)
        return sp

    add("devices", cmd_devices, "listar USB extraíbles", dev=False)
    s = add("list", cmd_list, "listar slots"); s.add_argument("-a", "--all", action="store_true")
    s = add("ls", cmd_ls, "listar archivos de un slot"); s.add_argument("slot", type=int)
    s = add("format", cmd_format, "formatear slots", write=True)
    s.add_argument("slot", type=int, nargs="+"); s.add_argument("--label")
    s = add("put", cmd_put, "copiar archivos a un slot"); s.add_argument("slot", type=int)
    s.add_argument("files", nargs="+"); s.add_argument("--dest", default="")
    s = add("get", cmd_get, "extraer un archivo"); s.add_argument("slot", type=int)
    s.add_argument("path"); s.add_argument("-o", "--out")
    s = add("rm", cmd_rm, "borrar archivo/carpeta"); s.add_argument("slot", type=int); s.add_argument("path")
    s = add("export", cmd_export, "guardar un slot como .img"); s.add_argument("slot", type=int); s.add_argument("out")
    s = add("import", cmd_import, "escribir un .img en un slot", write=True)
    s.add_argument("slot", type=int); s.add_argument("image")
    s = add("backup", cmd_backup, "copia de seguridad completa del USB"); s.add_argument("out")
    s = add("batch", cmd_batch, "copia por lotes (modos 1-4)", dev=False, write=True)
    s.add_argument("-d", "--device", help="USB/imagen (omitir con --dry-run)")
    s.add_argument("--slots", type=int)
    s.add_argument("src"); s.add_argument("start", type=int); s.add_argument("mode", type=int, choices=sorted(MODES))
    s.add_argument("--dry-run", action="store_true", help="solo vista previa"); s.add_argument("--contents-dir", default=".")
    return p


def main(argv=None):
    a = build_parser().parse_args(argv)
    try:
        if a.cmd == "batch" and not a.dry_run and not a.device:
            raise GotekError("Indica el dispositivo (o usa --dry-run).")
        a.fn(a)
    except GotekError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
