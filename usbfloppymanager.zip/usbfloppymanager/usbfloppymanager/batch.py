"""Copia por lotes (equivalente a GotekTool.sh) con 4 modos y vista previa."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from .core import Device, DiskFull, GotekError, Slot, make_blank_image, SLOT_SIZE

MODES = {
    1: "Aplanar: todos los archivos en la raíz de cada disquete",
    2: "Aplanar, pero cambiar de disquete en cada directorio",
    3: "Conservar la estructura de directorios",
    4: "Conservar estructura; cada carpeta raíz va a un disquete distinto",
}

DATA_CLUSTERS = 2847     # sectores de datos de un 1,44 MB (512 B/cluster)
ROOT_ENTRIES = 224


def natural_key(s: str):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


@dataclass
class Placement:
    floppy: int
    number: int          # nº de archivo dentro del disquete (1..n)
    src: str
    dest: str            # ruta dentro del disquete
    size: int
    status: str = "ok"   # ok | too_big | renamed


@dataclass
class BatchResult:
    placements: List[Placement] = field(default_factory=list)
    first: int = 0
    last: int = 0

    @property
    def skipped(self):
        return [p for p in self.placements if p.status == "too_big"]

    def contents_text(self) -> str:
        out, prev = [], None
        for p in self.placements:
            if p.status == "too_big":
                continue
            if prev is not None and p.floppy != prev:
                out.append("")
            out.append(f"{p.floppy}\t{p.number}\t{p.src}")
            prev = p.floppy
        return "\n".join(out) + "\n"


# ------------------------------------------------------------ destinos
class _SimFloppy:
    """Estimación de capacidad (aprox.): clusters de 512 B + entradas de directorio."""
    def __init__(self):
        self.clusters = DATA_CLUSTERS
        self.root = 0
        self.dirs = set()

    def try_add(self, dest: str, size: int, src: str) -> bool:
        parts = dest.split("/")
        need, new_dirs, root_add = -(-size // 512), [], 0
        acc = ""
        for i, d in enumerate(parts[:-1]):
            acc += "/" + d
            if acc not in self.dirs:
                new_dirs.append(acc)
                need += 1
                root_add += 1 if i == 0 else 0
        if len(parts) == 1:
            root_add += 1
        if need > self.clusters or self.root + root_add > ROOT_ENTRIES:
            return False
        self.clusters -= need
        self.root += root_add
        self.dirs.update(new_dirs)
        return True

    def exists(self, dest: str) -> bool:
        return False


class _RealFloppy:
    def __init__(self, dev: Device, n: int):
        dev.write_slot(n, make_blank_image(f"FD{n:03d}"))
        self.slot = Slot(dev, n)
        self.seen = set()

    def try_add(self, dest: str, size: int, src: str) -> bool:
        with open(src, "rb") as f:
            data = f.read()
        try:
            self.slot.write("/" + dest, data)
            return True
        except DiskFull:
            return False

    def close(self):
        self.slot.__exit__(None, None, None)


# ------------------------------------------------------------ motor
def list_files(srcdir: str) -> List[str]:
    out = []
    for root, _, files in os.walk(srcdir):
        for f in files:
            out.append(os.path.join(root, f))
    out.sort(key=natural_key)
    return out


def run_batch(srcdir: str, start: int, mode: int, dev: Optional[Device] = None,
              progress: Optional[Callable[[Placement], None]] = None) -> BatchResult:
    """dev=None => vista previa (estimación). Con dev => copia real."""
    if mode not in MODES:
        raise GotekError(f"Modo inválido: {mode}")
    srcdir = os.path.normpath(srcdir)
    if not os.path.isdir(srcdir):
        raise GotekError(f"No existe el directorio: {srcdir}")

    res = BatchResult(first=start)
    cur = start
    floppy = None

    def open_floppy(n):
        if dev is not None and n >= dev.n_slots:
            raise GotekError(f"El USB no tiene más slots (se necesita el {n}, máximo {dev.n_slots - 1}).")
        return _RealFloppy(dev, n) if dev else _SimFloppy()

    def close_floppy():
        if floppy is not None and dev is not None:
            floppy.close()

    floppy = open_floppy(cur)
    count, last_flip, names_here = 0, None, set()

    def next_floppy():
        nonlocal cur, floppy, count, names_here
        close_floppy()
        cur += 1
        floppy = open_floppy(cur)
        count, names_here = 0, set()

    try:
        for src in list_files(srcdir):
            rel = os.path.relpath(src, srcdir).replace(os.sep, "/")
            reldir, name = (rel.rsplit("/", 1) if "/" in rel else ("", rel))
            flip, dest_dir = None, reldir
            if mode == 2:
                flip = reldir
            elif mode == 4:
                flip = reldir.split("/")[0] if reldir else ""
                dest_dir = reldir.split("/", 1)[1] if "/" in reldir else ""
            if mode in (2, 4) and count > 0 and flip != last_flip:
                next_floppy()
            last_flip = flip

            if mode in (1, 2):
                dest = name
            else:
                dest = f"{dest_dir}/{name}" if dest_dir else name
            status = "ok"
            if dest in names_here:  # colisión al aplanar: renombrar
                stem, ext = os.path.splitext(name)
                i = 2
                while f"{stem}_{i}{ext}" in names_here:
                    i += 1
                dest, status = f"{stem}_{i}{ext}", "renamed"

            size = os.path.getsize(src)
            ok = floppy.try_add(dest, size, src)
            if not ok and count > 0:
                next_floppy()
                ok = floppy.try_add(dest, size, src)
            if not ok:
                pl = Placement(cur, 0, src, dest, size, "too_big")
            else:
                count += 1
                names_here.add(dest)
                pl = Placement(cur, count, src, dest, size, status)
            res.placements.append(pl)
            if progress:
                progress(pl)
    finally:
        close_floppy()
    res.last = cur
    return res


def write_contents(res: BatchResult, outdir: str = ".") -> str:
    path = os.path.join(outdir, f"Contents {res.first:03d}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(res.contents_text())
    return path
