"""Núcleo: acceso a slots de 1440 KiB separados 1536 KiB dentro de un USB/imagen,
formateo FAT12 y operaciones de archivos. Sin dependencias del sistema (no usa mount)."""
from __future__ import annotations

import os
import struct
import tempfile
from dataclasses import dataclass
from typing import Iterator, Optional

from pyfatfs.PyFatFS import PyFatFS

STRIDE = 1536 * 1024      # separación entre disquetes en el USB
SLOT_SIZE = 1440 * 1024   # tamaño útil de cada disquete
SECTOR = 512


class GotekError(Exception):
    pass


class DiskFull(GotekError):
    pass


# ---------------------------------------------------------------- formateo
def make_blank_image(label: str = "NO NAME") -> bytes:
    """Imagen FAT12 vacía de 1,44 MB (misma geometría que un disquete real)."""
    boot = bytearray(SECTOR)
    boot[0:3] = b"\xEB\x3C\x90"
    boot[3:11] = b"MSDOS5.0"
    struct.pack_into("<HBHBHHBHHHII", boot, 11,
                     512,    # bytes/sector
                     1,      # sectores/cluster
                     1,      # reservados
                     2,      # nº FAT
                     224,    # entradas raíz
                     2880,   # sectores totales
                     0xF0,   # media
                     9,      # sectores/FAT
                     18,     # sectores/pista
                     2,      # cabezas
                     0, 0)
    struct.pack_into("<BBBI", boot, 36, 0, 0, 0x29, 0x1234ABCD)
    boot[43:54] = label.upper().encode("ascii", "replace")[:11].ljust(11)
    boot[54:62] = b"FAT12   "
    boot[510:512] = b"\x55\xAA"
    img = bytearray(SLOT_SIZE)
    img[0:SECTOR] = boot
    for fat in range(2):  # dos copias de la FAT
        off = SECTOR * (1 + fat * 9)
        img[off:off + 3] = b"\xF0\xFF\xFF"
    return bytes(img)


def is_valid_fat12(data: bytes) -> bool:
    if len(data) < SECTOR or data[510:512] != b"\x55\xAA":
        return False
    bps, spc, rsv, nfat, root, tot16 = struct.unpack_from("<HBHBHH", data, 11)
    return bps == 512 and spc in (1, 2, 4) and nfat >= 1 and root > 0 and 0 < tot16 <= 2880


# ---------------------------------------------------------------- dispositivo
class Device:
    """USB (dispositivo en crudo) o archivo de imagen. Lee/escribe slots completos,
    siempre alineados a 512 bytes (necesario para dispositivos en crudo de Windows)."""

    def __init__(self, path: str, writable: bool = False, slots: Optional[int] = None):
        self.path = path
        self.writable = writable
        try:
            self._f = open(path, "r+b" if writable else "rb", buffering=0)
        except PermissionError as e:
            raise GotekError(f"Sin permisos para abrir {path}. Ejecuta como administrador/root.") from e
        except OSError as e:
            raise GotekError(f"No se puede abrir {path}: {e}") from e
        self.size = self._detect_size()
        if slots is not None:
            self.n_slots = slots
        elif self.size:
            self.n_slots = (self.size + STRIDE - SLOT_SIZE) // STRIDE if self.size >= SLOT_SIZE else 0
        else:
            raise GotekError("No se pudo detectar el tamaño del dispositivo; indica el nº de slots.")

    def _detect_size(self) -> int:
        try:
            return self._f.seek(0, os.SEEK_END)
        except OSError:
            return 0

    def close(self):
        self._f.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def _check(self, n: int):
        if not 0 <= n < self.n_slots:
            raise GotekError(f"Slot {n} fuera de rango (0..{self.n_slots - 1}).")

    def read_slot(self, n: int) -> bytes:
        self._check(n)
        self._f.seek(n * STRIDE)
        data = self._f.read(SLOT_SIZE)
        return data.ljust(SLOT_SIZE, b"\x00")

    def write_slot(self, n: int, data: bytes):
        if not self.writable:
            raise GotekError("Dispositivo abierto en solo lectura.")
        if len(data) != SLOT_SIZE:
            raise GotekError(f"Un slot debe tener {SLOT_SIZE} bytes (recibidos {len(data)}).")
        self._check(n)
        self._f.seek(n * STRIDE)
        self._f.write(data)
        try:
            os.fsync(self._f.fileno())
        except OSError:
            pass

    def format_slot(self, n: int, label: str = "NO NAME"):
        self.write_slot(n, make_blank_image(label))

    def slot_info(self, n: int) -> "SlotInfo":
        data = self.read_slot(n)
        if not is_valid_fat12(data):
            return SlotInfo(n, False, "", 0, 0, 0)
        label = data[43:54].decode("ascii", "replace").strip()
        with Slot(self, n, data=data) as s:
            files, used = s.stats()
        return SlotInfo(n, True, label, files, used, SLOT_SIZE)

    def iter_info(self) -> Iterator["SlotInfo"]:
        for n in range(self.n_slots):
            yield self.slot_info(n)


@dataclass
class SlotInfo:
    index: int
    valid: bool
    label: str
    files: int
    used_bytes: int
    total_bytes: int


@dataclass
class Entry:
    path: str        # ruta dentro del disquete, con "/"
    is_dir: bool
    size: int


# ---------------------------------------------------------------- slot
class Slot:
    """Vista de un disquete. Se trabaja sobre una copia temporal y se vuelca al USB
    con commit() (o al salir del `with` si hubo cambios)."""

    def __init__(self, dev: Device, n: int, data: Optional[bytes] = None):
        self.dev, self.n = dev, n
        data = data if data is not None else dev.read_slot(n)
        if not is_valid_fat12(data):
            raise GotekError(f"El slot {n} no contiene un FAT12 válido (fórmatealo primero).")
        fd, self._tmp = tempfile.mkstemp(suffix=".img")
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        self._fs = PyFatFS(self._tmp, read_only=not dev.writable)
        self.dirty = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *a):
        try:
            if exc_type is None and self.dirty:
                self.commit()
        finally:
            self.close()

    def close(self):
        try:
            self._fs.close()
        finally:
            if os.path.exists(self._tmp):
                os.remove(self._tmp)

    def commit(self):
        self._fs.close()
        with open(self._tmp, "rb") as f:
            data = f.read(SLOT_SIZE)
        self.dev.write_slot(self.n, data)
        self.dirty = False
        self._fs = PyFatFS(self._tmp, read_only=not self.dev.writable)

    # -- consulta
    def walk(self, base: str = "/") -> Iterator[Entry]:
        for info in self._fs.scandir(base):
            p = base.rstrip("/") + "/" + info.name
            if info.is_dir:
                yield Entry(p, True, 0)
                yield from self.walk(p)
            else:
                yield Entry(p, False, info.size)

    def stats(self) -> tuple[int, int]:
        files = used = 0
        for e in self.walk():
            if not e.is_dir:
                files += 1
                used += e.size
        return files, used

    def read(self, path: str) -> bytes:
        return self._fs.readbytes(path)

    # -- modificación
    def write(self, path: str, data: bytes):
        parent = path.rsplit("/", 1)[0] if "/" in path.strip("/") else ""
        if parent:
            self._fs.makedirs(parent, recreate=True)
        try:
            self._fs.writebytes(path, data)
        except Exception as e:  # pyfatfs lanza distintas excepciones al llenarse
            try:
                if self._fs.exists(path):
                    self._fs.remove(path)
            except Exception:
                pass
            raise DiskFull(str(e)) from e
        self.dirty = True

    def remove(self, path: str):
        if self._fs.isdir(path):
            self._fs.removetree(path)
        else:
            self._fs.remove(path)
        self.dirty = True

    def clear(self):
        for info in list(self._fs.scandir("/")):
            self.remove("/" + info.name)


def export_image(dev: Device, n: int, out_path: str):
    with open(out_path, "wb") as f:
        f.write(dev.read_slot(n))


def import_image(dev: Device, n: int, in_path: str):
    data = open(in_path, "rb").read()
    if len(data) < SLOT_SIZE:
        data = data.ljust(SLOT_SIZE, b"\x00")
    if len(data) != SLOT_SIZE or not is_valid_fat12(data):
        raise GotekError("La imagen no es un disquete FAT12 de 1,44 MB válido.")
    dev.write_slot(n, data)


def backup_device(dev: Device, out_path: str, progress=None):
    with open(out_path, "wb") as f:
        for n in range(dev.n_slots):
            f.seek(n * STRIDE)
            f.write(dev.read_slot(n))
            if progress:
                progress(n + 1, dev.n_slots)
