"""Detección de dispositivos USB extraíbles (Linux y Windows)."""
from __future__ import annotations
import json, os, subprocess, sys
from dataclasses import dataclass
from typing import List


@dataclass
class UsbDevice:
    path: str
    size: int
    model: str


def list_usb_devices() -> List[UsbDevice]:
    if sys.platform.startswith("linux"):
        out = []
        base = "/sys/block"
        for name in sorted(os.listdir(base)):
            try:
                rd = lambda f: open(f"{base}/{name}/{f}").read().strip()
                if rd("removable") != "1" or int(rd("size")) == 0:
                    continue
                try:
                    model = rd("device/model")
                except OSError:
                    model = ""
                out.append(UsbDevice(f"/dev/{name}", int(rd("size")) * 512, model))
            except (OSError, ValueError):
                continue
        return out
    if sys.platform == "win32":
        ps = ("Get-CimInstance Win32_DiskDrive | Where-Object {$_.InterfaceType -eq 'USB' -or "
              "$_.MediaType -like 'Removable*'} | Select-Object DeviceID,Size,Model | ConvertTo-Json")
        try:
            raw = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                 capture_output=True, text=True, timeout=20).stdout.strip()
            if not raw:
                return []
            data = json.loads(raw)
            data = data if isinstance(data, list) else [data]
            return [UsbDevice(d["DeviceID"], int(d["Size"] or 0), d.get("Model") or "") for d in data]
        except Exception:
            return []
    return []
